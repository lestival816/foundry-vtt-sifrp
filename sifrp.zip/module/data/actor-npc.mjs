import SifrpActorBase from './base-actor.mjs';

export default class SifrpNPC extends SifrpActorBase {

  //** @override */
  static defineSchema() {
    const schema = super.defineSchema();

    return schema;
  }

  //** @override */
  prepareDerivedData() {
    super.prepareDerivedData();

  }


}
