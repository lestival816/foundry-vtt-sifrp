export const SIFRP_CONSTANTS = {}

SIFRP_CONSTANTS.Settings = {
    SYSTEM_NAME: "sifrp",
    SYSTEM_NAME_LONG: "A Song of Ice anf Fire Roleplaying (Unofficial)",
    CURRENT_VERSION: "0.1.3",
    DEBUG_LOGS: "debugLogs"
}

// SIRFRP_CONSTANTS.Default_Icons = {
//     weapon: "icons/weapons/swords/sword-guard-steel.webp",
//     armor: "icons/armor/chest/chest-armor-steel-grey.webp",
// }

//  _preCreate, updates.img = SIFRP_SYSTEM.defaultIcons[this.type];
